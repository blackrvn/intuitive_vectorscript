# vectorpy
A collection of useful python scripts, functions and classes for vectorworks
